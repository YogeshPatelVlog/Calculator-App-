package com.example.calculator;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private EditText editTextNumber;//first Number
    private EditText editTextNumber2;//Second Number
    private Button button;//add Button
    private Button button2; // subtract button
    private Button button3;// Divide Button
    private Button button4;// Multiply Button
    private TextView textView4; // show output result
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        editTextNumber = findViewById(R.id.editTextNumber);
        editTextNumber2 = findViewById(R.id.editTextNumber2);
        button = findViewById(R.id.button);
        button2 = findViewById(R.id.button2);
        button3 = findViewById(R.id.button3);
        button4 = findViewById(R.id.button4);
        textView4 = findViewById(R.id.textView4);


        button .setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {

                String num1 = editTextNumber.getText().toString();
                String num2 = editTextNumber2.getText().toString();
                if(num1.isEmpty() && num2.isEmpty()){
                    Toast.makeText(MainActivity.this, "Please Enter Values !!", Toast.LENGTH_SHORT).show();
                }
                double val1 = Integer.parseInt(num1);
                double val2 = Integer.parseInt(num2);
                int sum = (int) (val1 + val2);
                textView4.setText(""+sum);

            }
        });
        button2 .setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String num1 = editTextNumber.getText().toString();
                String num2 = editTextNumber2.getText().toString();
                double val1 = Integer.parseInt(num1);
                double val2 = Integer.parseInt(num2);
                int sub = (int) (val1 - val2);
                textView4.setText(""+sub);
            }
        });
        button3.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String num1 = editTextNumber.getText().toString();
                String num2 = editTextNumber2.getText().toString();
                int val1 = Integer.parseInt(num1);
                int val2 = Integer.parseInt(num2);
                try {
                    int divide = val1 / val2;
                    textView4.setText("" + divide);
                }catch(ArithmeticException e){
                    Toast.makeText(MainActivity.this, "Cannot Divisible by Zero", Toast.LENGTH_SHORT).show();
                }
            }
        });
        button4.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                String num1 = editTextNumber.getText().toString();
                String num2 = editTextNumber2.getText().toString();
                double val1 = Integer.parseInt(num1);
                double val2 = Integer.parseInt(num2);
                int Multiply = (int) ((double) val1 * val2);
                textView4.setText(""+Multiply);
            }
        });

    }
}